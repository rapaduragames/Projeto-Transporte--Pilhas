using ProjetoTransporte.Models;

namespace ProjetoTransporte.Services;

public class TransporteService
{
    private readonly List<Garagem> _garagens = new();
    private readonly List<Veiculo> _veiculos = new();
    private readonly List<Viagem> _viagensDoDia = new();

    public IReadOnlyList<Garagem> Garagens => _garagens.AsReadOnly();
    public bool JornadaAtiva { get; private set; }

    public void ConfigurarDadosIniciais()
    {
        if (_garagens.Count > 0) return;

        _garagens.Add(new Garagem("Congonhas"));
        _garagens.Add(new Garagem("Guarulhos"));

        for (int i = 1; i <= 8; i++)
            _veiculos.Add(new Veiculo(i, 15));
    }

    public Veiculo CadastrarVeiculo(int capacidade)
    {
        GarantirJornadaEncerrada();
        Veiculo veiculo = new(_veiculos.Count == 0 ? 1 : _veiculos.Max(v => v.Id) + 1, capacidade);
        _veiculos.Add(veiculo);
        return veiculo;
    }

    public void CadastrarGaragem(string nome)
    {
        GarantirJornadaEncerrada();
        if (string.IsNullOrWhiteSpace(nome))
            throw new ArgumentException("Informe um nome para a garagem.");
        if (_garagens.Any(g => g.Nome.Equals(nome.Trim(), StringComparison.OrdinalIgnoreCase)))
            throw new ArgumentException("Já existe uma garagem com esse nome.");

        _garagens.Add(new Garagem(nome));
    }

    public void IniciarJornada()
    {
        if (JornadaAtiva)
            throw new InvalidOperationException("A jornada já está em andamento.");
        if (_garagens.Count < 2)
            throw new InvalidOperationException("É necessário cadastrar pelo menos duas garagens.");
        if (_veiculos.Count == 0)
            throw new InvalidOperationException("Cadastre pelo menos um veículo.");

        foreach (Garagem garagem in _garagens)
            garagem.Esvaziar();

        // Distribuição alternada entre as garagens cadastradas.
        for (int i = 0; i < _veiculos.Count; i++)
            _garagens[i % _garagens.Count].Estacionar(_veiculos[i]);

        _viagensDoDia.Clear();
        foreach (Veiculo veiculo in _veiculos)
            veiculo.LimparDadosDiarios();

        JornadaAtiva = true;
        Console.WriteLine("Jornada iniciada. Veículos distribuídos alternadamente entre as garagens.");
    }

    public void EncerrarJornada()
    {
        if (!JornadaAtiva)
            throw new InvalidOperationException("Não existe jornada em andamento.");

        Console.WriteLine("\n========== RELATÓRIO DA JORNADA ==========");
        foreach (Veiculo veiculo in _veiculos.OrderBy(v => v.Id))
        {
            Console.WriteLine(
                $"Veículo {veiculo.Id}: {veiculo.PassageirosTransportados} passageiros " +
                $"em {veiculo.ViagensRealizadas} viagem(ns).");
        }
        Console.WriteLine($"Total de viagens: {_viagensDoDia.Count}");
        Console.WriteLine($"Total de passageiros: {_viagensDoDia.Sum(v => v.Passageiros)}");
        Console.WriteLine("==========================================");

        _viagensDoDia.Clear();
        foreach (Veiculo veiculo in _veiculos)
            veiculo.LimparDadosDiarios();

        JornadaAtiva = false;
        Console.WriteLine("Jornada encerrada. Os registros diários foram limpos.");
    }

    public void LiberarViagem(string origem, string destino)
    {
        if (!JornadaAtiva)
            throw new InvalidOperationException("Inicie a jornada antes de liberar viagens.");

        Garagem garagemOrigem = ObterGaragem(origem);
        Garagem garagemDestino = ObterGaragem(destino);

        if (garagemOrigem.Nome.Equals(garagemDestino.Nome, StringComparison.OrdinalIgnoreCase))
            throw new ArgumentException("A origem e o destino devem ser diferentes.");

        if (garagemOrigem.QuantidadeVeiculos == 0)
            throw new InvalidOperationException(
                $"A garagem '{garagemOrigem.Nome}' está vazia. Aguarde um veículo retornar a esta garagem.");

        Veiculo veiculo = garagemOrigem.RetirarProximo();
        garagemDestino.Estacionar(veiculo);

        // A regra do enunciado considera a lotação completa em cada saída.
        veiculo.RegistrarViagem(veiculo.Capacidade);
        _viagensDoDia.Add(new Viagem(
            veiculo.Id, garagemOrigem.Nome, garagemDestino.Nome, veiculo.Capacidade));

        Console.WriteLine(
            $"Viagem liberada: veículo {veiculo.Id}, de {garagemOrigem.Nome} para {garagemDestino.Nome}, " +
            $"{veiculo.Capacidade} passageiros.");
    }

    public Garagem ObterGaragem(string nome)
    {
        Garagem? garagem = _garagens.FirstOrDefault(
            g => g.Nome.Equals(nome?.Trim(), StringComparison.OrdinalIgnoreCase));

        return garagem ?? throw new ArgumentException($"Garagem '{nome}' não encontrada.");
    }

    public int QuantidadeViagens(string origem, string destino) =>
        FiltrarViagens(origem, destino).Count;

    public List<Viagem> ListarViagens(string origem, string destino) =>
        FiltrarViagens(origem, destino).OrderBy(v => v.DataHora).ToList();

    public int QuantidadePassageiros(string origem, string destino) =>
        FiltrarViagens(origem, destino).Sum(v => v.Passageiros);

    private List<Viagem> FiltrarViagens(string origem, string destino)
    {
        Garagem gOrigem = ObterGaragem(origem);
        Garagem gDestino = ObterGaragem(destino);

        return _viagensDoDia.Where(v =>
            v.Origem.Equals(gOrigem.Nome, StringComparison.OrdinalIgnoreCase) &&
            v.Destino.Equals(gDestino.Nome, StringComparison.OrdinalIgnoreCase)).ToList();
    }

    private void GarantirJornadaEncerrada()
    {
        if (JornadaAtiva)
            throw new InvalidOperationException("Cadastros só podem ser realizados com a jornada encerrada.");
    }
}
