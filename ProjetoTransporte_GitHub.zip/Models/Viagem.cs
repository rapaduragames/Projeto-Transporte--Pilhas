namespace ProjetoTransporte.Models;

public class Viagem
{
    public int VeiculoId { get; }
    public string Origem { get; }
    public string Destino { get; }
    public int Passageiros { get; }
    public DateTime DataHora { get; }

    public Viagem(int veiculoId, string origem, string destino, int passageiros)
    {
        VeiculoId = veiculoId;
        Origem = origem;
        Destino = destino;
        Passageiros = passageiros;
        DataHora = DateTime.Now;
    }
}
