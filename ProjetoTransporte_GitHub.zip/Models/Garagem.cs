namespace ProjetoTransporte.Models;

public class Garagem
{
    private readonly Stack<Veiculo> _veiculos = new();

    public string Nome { get; }
    public int QuantidadeVeiculos => _veiculos.Count;
    public int PotencialTransporte => _veiculos.Sum(v => v.Capacidade);

    public Garagem(string nome)
    {
        if (string.IsNullOrWhiteSpace(nome))
            throw new ArgumentException("O nome da garagem não pode ficar vazio.");
        Nome = nome.Trim();
    }

    public void Estacionar(Veiculo veiculo) => _veiculos.Push(veiculo);

    public Veiculo RetirarProximo()
    {
        if (_veiculos.Count == 0)
            throw new InvalidOperationException($"A garagem '{Nome}' está vazia.");
        return _veiculos.Pop();
    }

    public List<Veiculo> VeiculosDoTopoAteOFundo() => _veiculos.ToList();

    public void Esvaziar()
    {
        _veiculos.Clear();
    }
}
