namespace ProjetoTransporte.Models;

public class Veiculo
{
    public int Id { get; }
    public int Capacidade { get; }
    public int ViagensRealizadas { get; private set; }
    public int PassageirosTransportados { get; private set; }

    public Veiculo(int id, int capacidade)
    {
        if (capacidade <= 0) throw new ArgumentException("A capacidade deve ser maior que zero.");
        Id = id;
        Capacidade = capacidade;
    }

    public void RegistrarViagem(int passageiros)
    {
        ViagensRealizadas++;
        PassageirosTransportados += passageiros;
    }

    public void LimparDadosDiarios()
    {
        ViagensRealizadas = 0;
        PassageirosTransportados = 0;
    }
}
